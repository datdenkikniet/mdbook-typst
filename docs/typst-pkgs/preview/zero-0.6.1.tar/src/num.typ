#import "state.typ": num-state, update-num-state
#import "formatting.typ": *
#import "rounding.typ": *
#import "assertions.typ": *
#import "parsing.typ" as parsing: nonum

#let update-state(state, args, name: none) = {
  assert-no-fixed(args)
  state.update(s => {
    assert-settable-args(args, s, name: name)
    s + args.named()
  })
}


#let set-num(..args) = update-state(num-state, args, name: "set-num")

#let set-group(..args) = {
  num-state.update(s => {
    assert-settable-args(args, s.group, name: "set-group")
    s.group += args.named()
    s
  })
}

#let set-round(..args) = {
  num-state.update(s => {
    assert-settable-args(args, s.round, name: "set-round")
    s.round += args.named()
    s
  })
}


// Process the exponent with its various modes mode
#let process-exponent(info, exponent) = {
  let new-exponent = if type(exponent) == dictionary {
    assert(
      "fixed" in exponent or "sci" in exponent,
      message: "Expected key \"fixed\" or \"sci\", got " + repr(exponent),
    )

    if "fixed" in exponent {
      exponent.fixed
    } else {
      let threshold = exponent.sci
      if type(threshold) == int {
        threshold = (-threshold, threshold)
      }
      let e = parsing.compute-sci-digits(info)
      if e > threshold.at(0) and e < threshold.at(1) {
        return info
      }
      e
    }
  } else if exponent == "eng" {
    parsing.compute-eng-digits(info)
  } else if exponent == "sci" {
    parsing.compute-sci-digits(info)
  }

  let e = if info.e == none { 0 } else { int(info.e) }
  // let significant-figures = (info.int + info.frac).trim("0").len()

  let shift = utility.shift-decimal-left.with(digits: new-exponent - e)

  info.e = str(new-exponent).replace("−", "-")
  (info.int, info.frac) = shift(info.int, info.frac)

  if info.pm != none {
    if type(info.pm.first()) != array {
      info.pm = shift(..info.pm)
    } else {
      info.pm = pm.map(x => shift(..x))
    }
  }
  // if info.int != "0" {
  //   info.frac = info.frac.slice(0, calc.max(0, significant-figures - info.int.len()))
  // }

  info
}



#let show-num = it => {
  // Process input
  let info
  if type(it.number) == dictionary {
    info = it.number
    if "mantissa" in info {
      let mantissa = info.mantissa
      if type(mantissa) in (int, float) {
        mantissa = str(mantissa).replace("−", "-")
      }
      let (sign, int, frac) = parsing.decompose-signed-float-numeral(mantissa)
      info += (sign: sign, int: int, frac: frac)
    }
    if "sign" not in info { info.sign = "" }
  } else {
    info = parse-numeral(it.number)
  }

  if it.exponent != auto {
    info = process-exponent(info, it.exponent)
    if "prefixed-eng" in it {
      info.e = none
    }
  }

  /// Round number and uncertainty
  if it.round.precision != none {
    (info.int, info.frac, info.pm) = round(
      info.int,
      info.frac,
      pm: info.pm,
      ..it.round,
    )
  }

  let digits = if it.digits == auto { info.frac.len() } else { it.digits }
  if digits < 0 {
    assert(false, message: "`digits` needs to be positive, got " + str(digits))
  }

  if info.pm != none {
    let pm = info.pm
    if type(pm.first()) != array { pm = (pm,) }
    digits = calc.max(digits, ..pm.map(array.last).map(str.len))
  }

  // info.digits = digits
  it.digits = digits

  // Format number
  let components = show-num-impl(info + it)
  let collect = if it.math { equation-from-items } else { it => it.join() }

  if it.align == none {
    set text(dir: ltr)
    it.prefix + collect(components.join()) + it.suffix
  } else if it.align == "components" {
    components.map(c => {
      set text(dir: ltr)
      collect(c)
    })
  } else {
    set text(dir: ltr)

    let (col-widths, col) = it.align
    let components = components.map(x => if x == () { none } else {
      collect(x)
    })
    components.at(0) = it.prefix + components.at(0)
    if it.suffix != none {
      if components.at(2) == none and components.at(3) == none {
        components.at(1) += it.suffix
      } else {
        components.at(3) += it.suffix
      }
    }
    let widths = components.map(x => if x == none { 0pt } else {
      measure(x).width
    })

    if col-widths != auto {
      for i in range(4) {
        let alignment = if i == 0 { right } else { left }
        let content = align(alignment, components.at(i))
        components.at(i) = box(width: col-widths.at(i), content)
      }
    }

    [#components.join()#metadata((col,) + widths)<__pillar-num__>]
  }
}


#let num(
  number,
  align: none,
  state: auto,
  prefix: none,
  suffix: none,
  force-parentheses-around-uncertainty: false,
  ..args,
) = {
  assert-no-fixed(args)

  let inline-args = (
    align: align,
    prefix: prefix,
    suffix: suffix,
    fpau: force-parentheses-around-uncertainty,
  )

  if type(number) == array {
    let named = args.named()
    let num-state = if state == auto { num-state.get() } else { state }
    let it = num-state + inline-args + args.named()
    return number.map(n => show-num(it + (number: n)))
  }

  if state != auto {
    let it = (
      update-num-state(state, args.named()) + inline-args + (number: number)
    )
    return show-num(it)
  }
  context {
    let it = (
      update-num-state(num-state.get(), args.named())
        + inline-args
        + (number: number)
    )
    show-num(it)
  }
}









/*

- Mantissa (value or uncertainty): Doesn't really need a show rule?
- Power: A rule would be beneficial. Does the multiplier need to be included?


Question: How to pass values on to the nested types

#set num.power(base: [5])
and then
#num(power: (base: [4]), "1.23e4")


show num.power: it => {
  - it.exponent [2.3]
  - it.base [10]
  - it.multiplier [×] ??

  math.attach([#it.base], t: [#it.exponent])

  or

  (
    box(),
    it.multiplier,
    math.attach([#it.base], t: [#it.exponent])
  )
}


show num.exponent: it => {
  - it.sign
  - it.integer
  - it.fractional

  it.sign + format-integer(it.integer) + format-fractional(it.fractional).join()
}


show num.uncertainty: it => {
  - it.value ([0.2, 0.4])
  - it.mode
  - it.symmetric false
  if it.mode == ...

  if it.symmetric {
    return (
      math.class("normal", none),
      math.class(if state.tight {"normal"} else {"binary"}, sym.plus.minus),
      it.value
    )
  } else {
    math.attach(none, t: sym.plus + it.value.at(0), b: sym.minus + it.value.at(1)),
  }
}

show num.num: it => {

}



*/

